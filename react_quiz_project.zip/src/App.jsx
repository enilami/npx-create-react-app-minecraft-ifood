
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Cadastro from "./components/Cadastro";
import Home from "./components/Home";
import EditarQuiz from "./components/EditarQuiz";
import DetalhesQuiz from "./components/DetalhesQuiz";
import JogarQuiz from "./components/JogarQuiz";
import { useState } from "react";

function App() {
  const [user, setUser] = useState("");

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Cadastro setUser={setUser} />} />
        <Route path="/home" element={<Home />} />
        <Route path="/editar/:id" element={<EditarQuiz />} />
        <Route path="/detalhes/:id" element={<DetalhesQuiz />} />
        <Route path="/jogar/:id" element={<JogarQuiz user={user} />} />
      </Routes>
    </Router>
  );
}

export default App;
