
import { useNavigate } from "react-router-dom";
import { useState } from "react";

export default function Cadastro({ setUser }) {
  const [nome, setNome] = useState("");
  const [sobrenome, setSobrenome] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const nomeCompleto = nome + " " + sobrenome;
    setUser(nomeCompleto);
    navigate("/home");
  };

  return (
    <div className="max-w-md mx-auto p-4">
      <h1 className="text-2xl mb-4">Bem-vindo! Cadastre-se para jogar:</h1>
      <form onSubmit={handleSubmit} className="grid gap-4">
        <input
          type="text"
          placeholder="Nome"
          value={nome}
          onChange={(e) => setNome(e.target.value)}
          className="border p-2 rounded"
          required
        />
        <input
          type="text"
          placeholder="Sobrenome"
          value={sobrenome}
          onChange={(e) => setSobrenome(e.target.value)}
          className="border p-2 rounded"
          required
        />
        <button type="submit" className="bg-green-600 text-white p-2 rounded">
          Entrar
        </button>
      </form>
    </div>
  );
}
