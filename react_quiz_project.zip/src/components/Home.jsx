
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Home() {
  const [quizzes, setQuizzes] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const quizzesSalvos = JSON.parse(localStorage.getItem("quizzes")) || [];
    setQuizzes(quizzesSalvos);
  }, []);

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl my-4">Escolha um Quiz</h1>
      <ul className="grid gap-4">
        {quizzes.map((quiz) => (
          <li key={quiz.id} className="p-4 border rounded bg-white flex justify-between">
            <span>{quiz.titulo}</span>
            <button
              className="bg-green-600 text-white px-3 py-1 rounded"
              onClick={() => navigate(`/detalhes/${quiz.id}`)}
            >
              Jogar
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
