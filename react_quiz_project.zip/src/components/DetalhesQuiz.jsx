// Em breve: detalhes do quiz antes de jogar
